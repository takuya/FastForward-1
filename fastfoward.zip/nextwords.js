var DefaultNextWords = [
  ">",
  ">>",
  "->",
  "- >",
  "-->",
  "-- >",
  "=>",
  "= >",
  "==>",
  "== >",
  "Next",
  "Next page",
  "[Next]",
  "Next >>",
  "Next=>",
  "Next =>",
  "Next==>",
  "Next ==>",
  "&#187;",
  "次へ",
  "次の",
  "次を",
  "次ページ",
];

var DefaultExcludedUrls = [
  "http://www.google.com/intl/en/options/",
];